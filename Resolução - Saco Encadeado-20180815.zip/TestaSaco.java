package teste;

import br.ufms.facom.edpoo.Saco;
import br.ufms.facom.edpoo.SacoEncadeado;
import edu.princeton.cs.algs4.StdOut;

public class TestaSaco {

	public static void main(String[] args) {
		// Cria um novo saco de números inteiros.
		Saco<Integer> saco = new SacoEncadeado<>();

		// Exibindo o número de itens no saco e se o mesmo está vazio.
		StdOut.printf("Número de itens: %d\n", saco.tamanho());
		StdOut.printf("Vazio? %s\n", saco.vazio() ? "Sim" : "Não");

		// Insere uma sequência de inteiros.
		StdOut.println("Inserindo itens...");
		for (int i = 0; i < 20; ++i)
			saco.insere(i);

		// Exibindo o número de itens no saco e se o mesmo está vazio.
		StdOut.printf("Número de itens: %d\n", saco.tamanho());
		StdOut.printf("Vazio? %s\n", saco.vazio() ? "Sim" : "Não");
	}

}
