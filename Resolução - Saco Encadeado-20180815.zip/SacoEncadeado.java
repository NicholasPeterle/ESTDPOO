package br.ufms.facom.edpoo;

import java.util.Iterator;

/**
 * Implementa um saco usando uma lista encadeada.
 * 
 * @author Eraldo R. Fernandes (eraldo@facom.ufms.br)
 *
 * @param <T>
 */
public class SacoEncadeado<T> implements Saco<T> {

	/**
	 * Número de elementos no saco.
	 */
	private int n;

	/**
	 * Referência para o primeiro nó da lista encadeada.
	 */
	private No<T> primeiro;

	/**
	 * Construtor padrão: constrói uma lista vazia.
	 */
	public SacoEncadeado() {
		this.primeiro = null;
	}

	@Override
	public Iterator<T> iterator() {
		return null;
	}

	@Override
	public void insere(T item) {
		primeiro = new No<T>(item, primeiro);
		++n;
	}

	@Override
	public boolean vazio() {
		return primeiro == null;
	}

	@Override
	public int tamanho() {
		return n;
	}

}
