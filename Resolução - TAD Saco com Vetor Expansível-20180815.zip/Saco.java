package br.ufms.facom.edpoo;

/**
 * TAD que representa uma coleção de itens sem ordem determinada (ordem
 * arbitrária) e permitindo itens repetidos.
 * 
 * As operações suportadas são: inserir um novo item, percorrer os itens
 * (extende {@code Iterable<T>}), retornar se o saco está vazio e retornar a
 * quantidade de itens no saco (tamanho do saco).
 * 
 * @author Eraldo R. Fernandes (eraldo@facom.ufms.br)
 *
 * @param <T>
 */
public interface Saco<T> extends Iterable<T> {

	/**
	 * Insere um item no saco. Mesmo que o item já esteja no saco, ele será
	 * inserido novamente, gerando uma duplicata.
	 * 
	 * @param item
	 *            item a ser inserido.
	 */
	public void insere(T item);

	/**
	 * Retorna se o saco está vazio.
	 * 
	 * @return
	 */
	public boolean vazio();

	/**
	 * Retorna o número de itens no saco.
	 * 
	 * @return
	 */
	public int tamanho();

}
