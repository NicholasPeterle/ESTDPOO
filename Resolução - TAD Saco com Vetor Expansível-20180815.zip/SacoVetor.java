package br.ufms.facom.edpoo;

import java.util.Arrays;
import java.util.Iterator;

/**
 * Implementa um saco usando um vetor e permitindo o redimensiosamento deste
 * vetor quando o mesmo enche.
 * 
 * @author eraldo
 *
 */
public class SacoVetor<T> implements Saco<T> {

	/**
	 * Vetor de itens.
	 */
	private T[] itens;

	/**
	 * Número de itens armazenados no saco.
	 */
	private int n;

	/**
	 * Cria um saco com capacidade padrão.
	 */
	public SacoVetor() {
		this(10);
	}

	/**
	 * Cria um saco com a dada capacidade.
	 * 
	 * @param max
	 */
	@SuppressWarnings("unchecked")
	public SacoVetor(int max) {
		this.n = 0;
		this.itens = (T[]) new Object[max];
	}

	@Override
	public Iterator<T> iterator() {
		return new Iterador();
	}

	@Override
	public void insere(T item) {
		if (n == itens.length)
			realoca();
		itens[n++] = item;
	}

	/**
	 * Realoca o vetor de itens com o dobro de tamanho.
	 */
	private void realoca() {
		itens = Arrays.copyOf(itens, itens.length * 2);
	}

	@Override
	public boolean vazio() {
		return n == 0;
	}

	@Override
	public int tamanho() {
		return n;
	}

	/**
	 * Classe aninhada (nested) que implementa um iterator nos itens de um saco.
	 * 
	 */
	private class Iterador implements Iterator<T> {

		/**
		 * Índice do item atual.
		 */
		private int i;

		/**
		 * Inicializa o iterator no início do array.
		 */
		public Iterador() {
			this.i = 0;
		}

		@Override
		public boolean hasNext() {
			return i < n;
		}

		@Override
		public T next() {
			return itens[i++];
		}

	}

}
